#!/bin/bash
cd data/squeeze/
gzip -k file_positions_de.txt