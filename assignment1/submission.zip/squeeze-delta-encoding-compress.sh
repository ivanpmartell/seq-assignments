detools create_patch HG00275.mapped.ILLUMINA.bwa.FIN.low_coverage.20120522.sam file_cigars.txt file_cigars.patch
detools create_patch HG00275.mapped.ILLUMINA.bwa.FIN.low_coverage.20120522.sam file_flags.txt file_flags.patch
detools create_patch HG00275.mapped.ILLUMINA.bwa.FIN.low_coverage.20120522.sam file_positions.txt file_positions.patch
detools create_patch HG00275.mapped.ILLUMINA.bwa.FIN.low_coverage.20120522.sam file_qualityscores.txt file_qualityscores.patch
detools create_patch HG00275.mapped.ILLUMINA.bwa.FIN.low_coverage.20120522.sam file_readnames.txt file_readnames.patch
detools create_patch HG00275.mapped.ILLUMINA.bwa.FIN.low_coverage.20120522.sam file_reads.txt file_reads.patch
