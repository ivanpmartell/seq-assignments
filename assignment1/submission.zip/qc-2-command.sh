#!/bin/bash
bash deinterleave.sh < interleaved.fastq mate_1.fastq mate_2.fastq