#!/bin/bash
cd data/squeeze/
gzip -k *.txt