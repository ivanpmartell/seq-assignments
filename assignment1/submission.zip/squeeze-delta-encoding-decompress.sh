detools apply_patch HG00275.mapped.ILLUMINA.bwa.FIN.low_coverage.20120522.sam file_cigars.patch file_cigars_decompressed.txt
detools apply_patch HG00275.mapped.ILLUMINA.bwa.FIN.low_coverage.20120522.sam file_flags.patch file_flags_decompressed.txt
detools apply_patch HG00275.mapped.ILLUMINA.bwa.FIN.low_coverage.20120522.sam file_positions.patch file_positions_decompressed.txt
detools apply_patch HG00275.mapped.ILLUMINA.bwa.FIN.low_coverage.20120522.sam file_qualityscores.patch file_qualityscores_decompressed.txt
detools apply_patch HG00275.mapped.ILLUMINA.bwa.FIN.low_coverage.20120522.sam file_readnames.patch file_readnames_decompressed.txt
detools apply_patch HG00275.mapped.ILLUMINA.bwa.FIN.low_coverage.20120522.sam file_reads.patch file_reads_decompressed.txt